function HomePage() {
  return <h1>My Home Page</h1>;
}

export default HomePage;
