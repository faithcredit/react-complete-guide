function NewEventPage() {
  return <h1>NewEventPage</h1>;
}

export default NewEventPage;
