function Post() {
  return (
    <div>
      <p>Maximilian</p>
      <p>React.js is awesome!</p>
    </div>
  );
}

export default Post;
