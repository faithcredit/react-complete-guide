import PostsList from './components/PostsList';

function App() {
  return (
    <main>
      <PostsList />
    </main>
  );
}

export default App;
