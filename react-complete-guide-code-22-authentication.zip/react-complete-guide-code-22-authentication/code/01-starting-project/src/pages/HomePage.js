import StartingPageContent from '../components/StartingPage/StartingPageContent';

const HomePage = () => {
  return <StartingPageContent />;
};

export default HomePage;
