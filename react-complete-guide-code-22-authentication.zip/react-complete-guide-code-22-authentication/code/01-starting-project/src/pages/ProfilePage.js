import UserProfile from '../components/profile/user-profile';

const ProfilePage = () => {
  return <UserProfile />;
};

export default ProfilePage;
