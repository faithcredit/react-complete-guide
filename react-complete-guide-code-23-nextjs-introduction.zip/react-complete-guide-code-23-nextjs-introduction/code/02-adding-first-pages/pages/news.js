// our-domain.com/news

function NewsPage() {
  return <h1>The News Page</h1>
}

export default NewsPage;