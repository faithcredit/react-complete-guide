const Output = props => {
  return <p>{props.children}</p>
};

export default Output;